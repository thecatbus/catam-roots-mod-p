15.6 COMPUTING ROOTS MODULO P
Code submission for part II CATAM coursework 

requirements: python 3
       	      random
              py-polynomials

files: ./src/jacobi.py
             main.py
             polyroots.py
             sqroots.py
       ./output (empty directory)

To run, open terminal in folder and run
$ python3 src/main.py
